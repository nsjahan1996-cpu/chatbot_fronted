const chatToggle = document.querySelector('#chatToggle');
const chatbot = document.querySelector('#chatbot');
const closeBtn = document.querySelector('.close-btn');
const chatWrapper = document.querySelector('.chat-wrapper');

chatToggle.addEventListener('click', () => {
  chatbot.classList.add('active');
  chatWrapper.classList.add('hide-icons'); // hide icons
});

closeBtn.addEventListener('click', () => {
  chatbot.classList.remove('active');
  chatWrapper.classList.remove('hide-icons'); // show icons again
});

function addMessage(text, sender){
  const msg = document.createElement('div');
  msg.classList.add('message');
  msg.classList.add(sender === 'user' ? 'user-message' : 'bot-message');
  msg.innerText = text;
  chatBody.appendChild(msg);
  chatBody.scrollTop = chatBody.scrollHeight; // auto scroll
}

// User sends message
sendBtn.addEventListener('click', () => {
  const text = chatInput.value.trim();
  if(text === '') return;
  
  addMessage(text, 'user');
  chatInput.value = '';

  // Simple auto-reply logic
  setTimeout(() => {
    let reply = "Sorry, I didn't understand that.";

    // Simple keyword responses
    if(text.toLowerCase().includes('hello')){
      reply = "Hi! How can I help you today?";
    } else if(text.toLowerCase().includes('order')){
      reply = "You can place your order from our products page.";
    } else if(text.toLowerCase().includes('offer')){
      reply = "Currently we have a 10% discount on selected items.";
    }

    addMessage(reply, 'bot');
  }, 500); // simulate typing delay
});

// Optional: Enter key sends message
chatInput.addEventListener('keypress', (e)=>{
  if(e.key === 'Enter'){
    sendBtn.click();
  }
});

